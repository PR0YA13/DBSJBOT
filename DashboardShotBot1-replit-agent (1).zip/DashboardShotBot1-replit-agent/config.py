import os

# Telegram Configuration
TELEGRAM_TOKEN = "7770923655:AAHcyQiCKWSYKRB9JfxsD9wMSAutdyCz9NQ"

# Google Sheets Configuration
SPREADSHEET_ID = "1o_RhLTXTC2D-W55sBvbftUnyJDv8z4OnbXoP-4tr_04"
SHEET_NAME = "тестовая ре-визуализация"
CREDENTIALS_FILE = "attached_assets/ageless-welder-451507-k4-31eed6cef9d3.json"

# Screenshot Service Configuration
APIFLASH_KEY = "c1271bca0a534933af8a069e3a336d64"
APIFLASH_URL = "https://api.apiflash.com/v1/urltoimage"

# Cache Configuration
CACHE_DURATION = 300  # 5 minutes in seconds